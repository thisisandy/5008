package lookandsay;
public class LookAndSayIteratorTest {
    
}
