/**
 * The ICombinable interface defines the contract for objects that can be combined with others.
 * Classes implementing this interface must provide a method to combine the current instance with another instance of the same type.
 */
public interface ICombinable {

    /**
     * Combines the current instance with another item, producing a new item as a result.
     * The specific rules for combining two items are to be defined in the implementation.
     *
     * @param item The item to be combined with the current instance.
     * @return A new Item object that results from the combination of the current instance with the provided item.
     */
    Item combine(Item item);
}
