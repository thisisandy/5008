public class HandGear extends Item implements IEquippable {
    final protected EquippableBodyPart bodyPartToEquip = EquippableBodyPart.ARMS;
    public HandGear(String name, String prefix, int attackStrength, int defenseStrength) {
        super(name, prefix ,  attackStrength, defenseStrength);
    }

    public void equip() {
        // Implementation here
    }

    public void unequip() {
        // Implementation here
    }

    @Override
    public EquippableBodyPart getBodyPartToEquip() {
        return bodyPartToEquip;
    }


}
