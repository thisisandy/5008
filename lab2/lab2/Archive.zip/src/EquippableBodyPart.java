/**
 * The EquippableBodyPart enumeration defines the types of body parts where items can be equipped.
 * This allows the game's system to recognize specific slots on a character's body where various items might be attached.
 */
public enum EquippableBodyPart {
    HEAD, // Represents the head of a character, where headgear can be equipped.
    ARMS, // Represents the arms of a character, where items like shields or bracers might be equipped.
    LEGS; // Represents the legs of a character, where items like boots or leg armor might be equipped.
}
