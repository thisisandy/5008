public class Footwear extends Item implements IEquippable {
    final protected EquippableBodyPart bodyPartToEquip = EquippableBodyPart.LEGS;
    public Footwear(String name,String property, int attackStrength, int defenseStrength) {
        super(name, property, attackStrength,defenseStrength);
    }

    public void equip() {
    }

    public void unequip() {
    }

    @Override
    public EquippableBodyPart getBodyPartToEquip() {
        return bodyPartToEquip;
    }

}
