/**
 * The WithHead interface represents a contract for any entity that has heads as part of its body.
 * It is an extension of the WithBodyPart interface, focusing specifically on the count of heads.
 */
public interface WithHead extends WithBodyPart {

    /**
     * Retrieves the number of heads associated with the implementing object.
     *
     * @return An integer representing the count of heads.
     */
    public int getHeadCount();
}
