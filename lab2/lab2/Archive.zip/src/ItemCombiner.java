/**
 * The ItemCombiner class is responsible for combining two items together.
 * It acts as a utility to call the combine method of the specified items.
 */
public class ItemCombiner {

    /**
     * Combines two Item objects into a new one.
     * The actual combining logic is defined in the Item's combine method.
     *
     * @param item1 The first item to be combined.
     * @param item2 The second item to be combined.
     * @return A new Item object resulting from the combination of the two provided items.
     */
    public Item combineItems(Item item1, Item item2) {
        return item1.combine(item2);
    }
}
