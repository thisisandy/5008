/**
 * The WithLegs interface represents a contract for any entity that has legs as part of its body.
 * It is an extension of the WithBodyPart interface, focusing specifically on the count of legs.
 */
public interface WithLegs extends WithBodyPart {

    /**
     * Retrieves the number of legs associated with the implementing object.
     *
     * @return An integer representing the count of legs.
     */
    public int getLegCount();
}
