import java.util.HashMap;

/**
 * The Character class represents a game character with specific body parts, attack, defense attributes, and an inventory system.
 * It is an abstract class and must be extended by specific character types (e.g., Human).
 * Implements interfaces WithLegs, WithHead, and WithArms to ensure that characters have specific body parts where items can be equipped.
 */
abstract public class Character implements WithLegs, WithHead, WithArms {
    private final String name;
    private int baseAttack;
    private int baseDefense;
    private Inventory inventory;

    private HashMap<EquippableBodyPart, Integer> bodyParts = new HashMap<>();

    /**
     * Constructs a Character with base attack, base defense, and a name.
     * Initializes the inventory and the count of equippable body parts.
     *
     * @param baseAttack    The base attack value for the character.
     * @param baseDefense   The base defense value for the character.
     * @param name          The name of the character.
     */
    public Character(int baseAttack, int baseDefense, String name) {
        this.baseAttack = baseAttack;
        this.baseDefense = baseDefense;
        this.name = name;
        this.bodyParts = new HashMap<EquippableBodyPart, Integer>() {{
            put(EquippableBodyPart.HEAD, getHeadCount());
            put(EquippableBodyPart.ARMS, getArmCount());
            put(EquippableBodyPart.LEGS, getLegCount());
        }};
        this.inventory = new Inventory(this);
    }

    /**
     * Calculates the total attack value by adding base attack and attack strength of all equipped items.
     *
     * @return The total attack value.
     */
    public int calculateTotalAttack() {
        int totalAttack = baseAttack;
        for (Slot slot : inventory.getSlots().values()) {
            for (Item item : slot.getItems()) {
                if (item == null) {
                    continue;
                }
                totalAttack += item.getAttackStrength();
            }
        }
        return totalAttack;
    }

    /**
     * Calculates the total defense value by adding base defense and defense strength of all equipped items.
     *
     * @return The total defense value.
     */
    public int calculateTotalDefense() {
        int totalDefense = baseDefense;
        for (Slot slot : inventory.getSlots().values()) {
            for (Item item : slot.getItems()) {
                if (item == null) {
                    continue;
                }
                totalDefense += item.getDefenseStrength();
            }
        }
        return totalDefense;
    }

    /**
     * Checks if the character can equip more items.
     *
     * @return True if there are empty slots, false otherwise.
     */
    public boolean canEquipMoreItems() {
        for (Slot slot : inventory.getSlots().values()) {
            if (!slot.isFull()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the character can equip more items of a specific type.
     *
     * @param equipmentType The type of equipment.
     * @return True if there are empty slots for the specified type, false otherwise.
     */
    public boolean canEquipMoreItems(EquippableBodyPart equipmentType) {
        return !inventory.getSlots().get(equipmentType).isFull();
    }

    /**
     * Checks if the character can equip a specific item.
     *
     * @param item The item to check.
     * @return True if the item can be equipped, false otherwise.
     */
    public boolean canEquipItem(Item item) {
        return inventory.getSlots().get(item.getBodyPartToEquip()).isFull();
    }

    /**
     * Adds an item to the character's inventory.
     *
     * @param item The item to be picked up.
     */
    public void pickUpItem(Item item) {
        inventory.addItem(item);
    }

    /**
     * Returns the count of a specific body part type.
     *
     * @param equipmentType The type of body part.
     * @return The count of the specified body part.
     */
    public int getBodyPartCount(EquippableBodyPart equipmentType) {
        return bodyParts.get(equipmentType);
    }

    /**
     * Returns the name of the character.
     *
     * @return The name of the character.
     */
    public String getName() {
        return name;
    }
}
