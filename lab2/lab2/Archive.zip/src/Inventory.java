import java.util.HashMap;
import java.util.Map;

/**
 * The Inventory class represents a collection of slots where items can be stored.
 * Each slot corresponds to an equippable body part and can contain one or more items.
 * The Inventory is responsible for managing these slots, including adding and removing items,
 * checking if the inventory is full, and initializing slots based on a character's body parts.
 */
public class Inventory {
    private Map<EquippableBodyPart, Slot> slots = new HashMap<>();

    /**
     * Constructs an Inventory object and initializes the slots based on the given character.
     *
     * @param character The character for whom the inventory is created.
     */
    public Inventory(Character character) {
        initializeSlots(character);
    }

    /**
     * Adds an item to the corresponding slot in the inventory.
     * If the slot is already full, the item will not be added.
     *
     * @param item The item to be added.
     */
    public void addItem(Item item) {
        Slot slot = slots.get(item.getBodyPartToEquip());
        if (!slot.isFull()) {
            slot.addItem(item);
        }
    }

    /**
     * Removes an item from the corresponding slot in the inventory.
     *
     * @param item The item to be removed.
     */
    public void removeItem(Item item) {
        Slot slot = slots.get(item.getBodyPartToEquip());
        if (slot.containsItem(item)) {
            slot.removeItem(item);
        }
    }

    /**
     * Checks if the inventory is full, meaning all slots are filled.
     *
     * @return true if the inventory is full, false otherwise.
     */
    public boolean isFull() {
        for (Slot slot : slots.values()) {
            if (!slot.isFull()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Initializes the slots in the inventory based on the body parts of the given character.
     *
     * @param character The character whose body parts are used to initialize the slots.
     */
    public void initializeSlots(Character character) {
        for (EquippableBodyPart type : EquippableBodyPart.values()) {
            slots.put(type, new Slot(character.getBodyPartCount(type), new Item[character.getBodyPartCount(type)]));
        }
    }

    /**
     * Equips an item to the corresponding slot in the inventory.
     *
     * @param item The item to be equipped.
     */
    public void equipItem(Item item) {
        Slot slot = slots.get(item.getBodyPartToEquip());
        if (!slot.isFull()) {
            slot.addItem(item);
        }
    }

    /**
     * Unequips an item from the corresponding slot in the inventory.
     *
     * @param item The item to be unequipped.
     */
    public void unequipItem(Item item) {
        Slot slot = slots.get(item.getBodyPartToEquip());
        if (slot.containsItem(item)) {
            slot.removeItem(item);
        }
    }

    /**
     * Returns a map of the slots in the inventory, keyed by the equippable body part.
     *
     * @return A map of the inventory slots.
     */
    public Map<EquippableBodyPart, Slot> getSlots() {
        return this.slots;
    }
}
