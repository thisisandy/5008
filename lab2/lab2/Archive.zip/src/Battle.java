import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 * The Battle class orchestrates a combat scenario between two characters.
 * It is responsible for generating random items for the characters, allowing them to pick and equip
 * the best-suited items, and then calculating the damage for each character to determine the winner.
 */
public class Battle {
    public  void Battle(Character player1, Character player2){
        Item[] items = generateRandomItems(20);

        List<Item> availableItems = new ArrayList<>(Arrays.asList(items));

        while (availableItems.size()>10) {
            pickUpItem(player1, availableItems);
            pickUpItem(player2, availableItems);
        }

        int player1Damage = player2.calculateTotalAttack() - player1.calculateTotalDefense();
        int player2Damage = player1.calculateTotalAttack() - player2.calculateTotalDefense();
        if (player1Damage > player2Damage) {
            System.out.println(player2.getName() + " wins");
        } else if (player2Damage > player1Damage) {
            System.out.println(player1.getName() + " wins");
        } else {
            System.out.println("It's a tie");
        }
    }
    /**
     * Allows a character to pick up an item from the available items list.
     * The character will prefer items that can be equipped to their available body parts
     * and will choose the one with the highest attack strength first.
     *
     * @param character The character picking up the item.
     * @param availableItems The list of available items.
     */
    private  void pickUpItem(Character character, List<Item> availableItems) {
        if (availableItems.isEmpty() || !character.canEquipMoreItems()) {
            return;
        }

        ArrayList<EquippableBodyPart> preferredType = new ArrayList<>();
        for (EquippableBodyPart bodyPart : EquippableBodyPart.values()) {
            if (character.canEquipMoreItems(bodyPart)) {
                preferredType.add(bodyPart);
            }
        }
        ArrayList<Item> preferredItems = new ArrayList<>();
        for (Item item : availableItems) {
            if (preferredType.contains(item.getBodyPartToEquip())) {
                preferredItems.add(item);
            }
        }
        if (preferredItems.isEmpty()) {
            System.out.println("No preferred items found for " + character.getName());
            character.pickUpItem(availableItems.get(0));
            availableItems.remove(0);
            return;
        }
        preferredItems.sort((item1, item2) -> {
            if (item1.getAttackStrength() > item2.getAttackStrength()) {
                return -1;
            } else if (item1.getAttackStrength() < item2.getAttackStrength()) {
                return 1;
            } else {
                if (item1.getDefenseStrength() > item2.getDefenseStrength()) {
                    return -1;
                } else if (item1.getDefenseStrength() < item2.getDefenseStrength()) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });
        Item itemToEquip = preferredItems.get(0);
        character.pickUpItem(itemToEquip);
        availableItems.remove(itemToEquip);
        System.out.println(character.getName() + " is picking up a piece of " + itemToEquip.getBodyPartToEquip().name() + ": " + itemToEquip.getPrefix() + " " + itemToEquip.getName() + " -- defense strength: " + itemToEquip.getDefenseStrength() + ", attack strength: " + itemToEquip.getAttackStrength());
    }

    /**
     * Generates an array of random items. The type and attributes of each item (e.g., attack and defense strength)
     * are determined randomly.
     *
     * @param count The number of items to generate.
     * @return An array of randomly generated items.
     */
    public  Item[] generateRandomItems(int count) {
        Item[] items = new Item[count];
        for (int i = 0; i < count; i++) {
            int random = (int) (Math.random() * 3);
            String name = "Item" + i;
            String prefix = "Prefix" + i;
            int defenseStrength = (int) (Math.random() * 10);
            int attackStrength = (int) (Math.random() * 10);
            switch (random) {
                case 0:
                    items[i] = new Footwear(name, prefix, attackStrength, defenseStrength);
                    break;
                case 1:
                    items[i] = new HeadGear(name, prefix, defenseStrength,defenseStrength);
                    break;
                case 2:
                    items[i] = new HandGear(name, prefix, defenseStrength,defenseStrength);
                    break;
                case 3:
                    break;
            }
        }
        return items;
    }
    /**
     * Generates a random character for the battle. It can either be a Human or an Alien, chosen randomly.
     *
     * @return A random character (Human or Alien).
     */
    public static Character generateRandomCharacter() {
        int random = (int) (Math.random() * 2);
        if (random == 0) {
            return new Human(10, 10);
        } else {
            return new Alien(10, 10);
        }
    }
}
