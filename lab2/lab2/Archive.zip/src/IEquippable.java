/**
 * The IEquippable interface defines the contract for objects that can be equipped and unequipped.
 * Classes implementing this interface must provide methods to equip and unequip the item.
 * This can be used in a context where items need to be associated or dissociated with a particular entity, such as a character in a game.
 */
public interface IEquippable {

    /**
     * Equips the item, associating it with a particular entity or enabling its effects.
     * The specific behavior of what happens when the item is equipped should be defined in the implementing class.
     */
    void equip();

    /**
     * Unequips the item, dissociating it from a particular entity or disabling its effects.
     * The specific behavior of what happens when the item is unequipped should be defined in the implementing class.
     */
    void unequip();
}
