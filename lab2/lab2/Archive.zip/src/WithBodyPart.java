/**
 * The WithBodyPart interface represents a contract for any entity that has definable body parts.
 * It provides a method to obtain the count of specific body parts that are equippable.
 */
public interface WithBodyPart {

    /**
     * Retrieves the number of a specific type of body part associated with the implementing object.
     *
     * @param equipmentType An enumeration of the specific equippable body part type for which the count is required.
     * @return An integer representing the count of the specified body part.
     */
    public int getBodyPartCount(EquippableBodyPart equipmentType);
}
