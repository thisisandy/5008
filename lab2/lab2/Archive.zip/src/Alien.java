/**
 * The Alien class represents a specific type of character within the battle simulation.
 * Aliens are distinct in their characteristics, having zero legs, three heads, and eight arms.
 * The Alien class extends the Character class, inheriting its attributes and behavior while
 * defining additional properties specific to an alien.
 */
public class Alien extends Character {

    /**
     * Constructs an Alien object with the specified base attack and base defense values.
     * The name is set to "Alien" by default.
     *
     * @param baseAttack The base attack strength of the alien.
     * @param baseDefense The base defense strength of the alien.
     */
    public Alien(int baseAttack, int baseDefense) {
        super(baseAttack, baseDefense, "Alien");
    }

    /**
     * Returns the number of legs the alien has, which is always zero for an alien.
     *
     * @return The number of legs, 0.
     */
    public int getLegCount() {
        return 0;
    }

    /**
     * Returns the number of heads the alien has, which is always three for an alien.
     *
     * @return The number of heads, 3.
     */
    public int getHeadCount() {
        return 3;
    }

    /**
     * Returns the number of arms the alien has, which is always eight for an alien.
     *
     * @return The number of arms, 8.
     */
    public int getArmCount() {
        return 8;
    }
}
