/**
 * The WithArms interface extends the WithBodyPart interface to provide a specific contract for any entity that has arms.
 * It includes a method to obtain the count of arms for the implementing object.
 */
public interface WithArms extends WithBodyPart {

    /**
     * Retrieves the number of arms associated with the implementing object.
     *
     * @return An integer representing the count of arms.
     */
    public int getArmCount();
}
