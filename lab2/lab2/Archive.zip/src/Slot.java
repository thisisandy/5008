/**
 * The Slot class represents a container for holding Items, with a specified maximum capacity.
 * It can add and remove items, combine them if the slot is full, and provides information about its contents.
 */
public class Slot {
    private int maxItems; // Maximum number of items that can be held in the slot
    private Item[] items; // Array to hold items
    private int currentItemsCount; // Current number of items in the slot
    private ItemCombiner itemCombiner = new ItemCombiner(); // Utility for combining items

    /**
     * Constructs a Slot with a given maximum capacity, initializing its items array.
     *
     * @param maxItems The maximum number of items the slot can hold.
     * @param items    Initial items to populate the slot.
     */
    public Slot(int maxItems, Item[] items) {
        this.maxItems = maxItems;
        this.items = new Item[maxItems];
        this.currentItemsCount = 0;
    }

    /**
     * Adds an item to the slot, if space is available.
     * If the slot is full, it will combine the item with the first item in the slot.
     *
     * @param item The item to add to the slot.
     */
    public void addItem(Item item) {
        if (!isFull()) {
            items[currentItemsCount++] = item;
        } else {
            System.out.println("Slot is full");
            itemCombiner.combineItems(items[0], item);
        }
    }

    /**
     * Removes a specific item from the slot, shifting the other items as necessary.
     *
     * @param item The item to remove from the slot.
     */
    public void removeItem(Item item) {
        for (int i = 0; i < currentItemsCount; i++) {
            if (items[i].equals(item)) {
                // Shift the items to fill the gap
                System.arraycopy(items, i + 1, items, i, currentItemsCount - i - 1);
                items[--currentItemsCount] = null;
                break;
            }
        }
    }

    /**
     * Checks if the slot is full, i.e., has reached its maximum capacity.
     *
     * @return true if the slot is full, false otherwise.
     */
    public boolean isFull() {
        return currentItemsCount == maxItems;
    }

    /**
     * Checks if the slot contains a specific item.
     *
     * @param item The item to search for in the slot.
     * @return true if the item is found in the slot, false otherwise.
     */
    public boolean containsItem(Item item) {
        for (int i = 0; i < currentItemsCount; i++) {
            if (items[i].equals(item)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Retrieves the items currently in the slot.
     *
     * @return An array of Item objects representing the contents of the slot.
     */
    public Item[] getItems() {
        return this.items;
    }

    /**
     * Retrieves the current count of items in the slot.
     *
     * @return An integer representing the current number of items in the slot.
     */
    public int getCurrentItemsCount() {
        return this.currentItemsCount;
    }

    /**
     * Retrieves the maximum capacity of the slot.
     *
     * @return An integer representing the maximum number of items the slot can hold.
     */
    public int getCapacity() {
        return this.maxItems;
    }
}
