/**
 * The Item class represents a general item that can be equipped and combined with other items.
 * It includes properties like name, prefix, attack strength, defense strength, and the body part to which it can be equipped.
 * This class implements both ICombinable and IEquippable interfaces, allowing instances of Item to be equipped, unequipped, and combined with other items.
 */
public class Item implements ICombinable, IEquippable {
    private String name;
    private final int attackStrength;
    private final int defenseStrength;

    final protected String prefix;

    protected EquippableBodyPart bodyPartToEquip;

    /**
     * Constructs an Item object with the given name, prefix, defense strength, and attack strength.
     *
     * @param name             The name of the item.
     * @param prefix           A string representing a prefix associated with the item.
     * @param defenseStrength  The defense strength value of the item.
     * @param attackStrength   The attack strength value of the item.
     */
    public Item(String name, String prefix,  int attackStrength, int defenseStrength) {
        this.prefix = prefix;
        this.name = name;
        this.attackStrength = attackStrength;
        this.defenseStrength = defenseStrength;
    }

    /**
     * Returns the name of the item.
     *
     * @return The name of the item.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the prefix associated with the item.
     *
     * @return The prefix of the item.
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Returns the attack strength of the item.
     *
     * @return The attack strength of the item.
     */
    public int getAttackStrength() {
        return attackStrength;
    }

    /**
     * Returns the defense strength of the item.
     *
     * @return The defense strength of the item.
     */
    public int getDefenseStrength() {
        return defenseStrength;
    }

    /**
     * Returns the body part to which the item can be equipped.
     *
     * @return The equippable body part.
     */
    public EquippableBodyPart getBodyPartToEquip() {
        return bodyPartToEquip;
    }

    /**
     * Implements the equip functionality. Implementation details should be provided by the specific subclass or usage context.
     */
    @Override
    public void equip() {
    }

    /**
     * Implements the unequip functionality. Implementation details should be provided by the specific subclass or usage context.
     */
    @Override
    public void unequip() {
    }

    /**
     * Combines this item with another item, creating a new item with the combined properties.
     *
     * @param item The item to combine with.
     * @return A new Item object with combined properties.
     */
    @Override
    public Item combine(Item item) {
        return new Item(this.getName(), this.getPrefix() + item.getPrefix(),  this.getAttackStrength() + item.getAttackStrength(), this.getDefenseStrength() + item.getDefenseStrength());
    }
}
