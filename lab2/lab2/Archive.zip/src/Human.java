/**
 * The Human class represents a human character in the game.
 * It extends the Character class and provides specific details about the human's body parts, such as the count of legs, heads, and arms.
 * Human characters are defined with base attack and defense values, and they always have two legs, one head, and two arms.
 */
public class Human extends Character {

    /**
     * Constructs a Human object with the given base attack and defense values.
     *
     * @param baseAttack The base attack value for the human character.
     * @param baseDefense The base defense value for the human character.
     */
    public Human(int baseAttack, int baseDefense) {
        super(baseAttack, baseDefense, "Human");
    }

    /**
     * Returns the count of legs for the human character, which is always 2.
     *
     * @return The number of legs (2).
     */
    @Override
    public int getLegCount() {
        return 2;
    }

    /**
     * Returns the count of heads for the human character, which is always 1.
     *
     * @return The number of heads (1).
     */
    @Override
    public int getHeadCount() {
        return 1;
    }

    /**
     * Returns the count of arms for the human character, which is always 2.
     *
     * @return The number of arms (2).
     */
    @Override
    public int getArmCount() {
        return 2;
    }
}
