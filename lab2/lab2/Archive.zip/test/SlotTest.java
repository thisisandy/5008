import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SlotTest {

    @Test
    void testAddItem() {
        Slot slot = new Slot(2, new Item[2]);
        Item item1 = new Item("Sword", "Sharp", 5, 15);
        Item item2 = new Item("Shield", "Sturdy", 10, 5);

        slot.addItem(item1);
        assertEquals(1, slot.getCurrentItemsCount());
        assertTrue(slot.containsItem(item1));

        slot.addItem(item2);
        assertEquals(2, slot.getCurrentItemsCount());
        assertTrue(slot.containsItem(item2));
    }

    @Test
    void testRemoveItem() {
        Slot slot = new Slot(2, new Item[2]);
        Item item1 = new Item("Sword", "Sharp", 5, 15);

        slot.addItem(item1);
        assertTrue(slot.containsItem(item1));

        slot.removeItem(item1);
        assertEquals(0, slot.getCurrentItemsCount());
        assertFalse(slot.containsItem(item1));
    }

    @Test
    void testIsFull() {
        Slot slot = new Slot(1, new Item[1]);
        Item item1 = new Item("Sword", "Sharp", 5, 15);

        assertFalse(slot.isFull());
        slot.addItem(item1);
        assertTrue(slot.isFull());
    }
}
