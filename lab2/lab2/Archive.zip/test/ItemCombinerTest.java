import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ItemCombinerTest {

    @Test
    void testCombineItems() {
        Item item1 = new Item("Sword", "Sharp", 5, 15);
        Item item2 = new Item("Shield", "Sturdy", 10, 5);
        ItemCombiner itemCombiner = new ItemCombiner();

        Item combinedItem = itemCombiner.combineItems(item1, item2);

        assertEquals("Sword", combinedItem.getName());
        assertEquals("SharpSturdy", combinedItem.getPrefix());
        assertEquals(15, combinedItem.getAttackStrength());
        assertEquals(20, combinedItem.getDefenseStrength());
    }
}
