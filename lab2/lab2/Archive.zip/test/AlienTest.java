import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AlienTest {

    private Alien alien;

    @BeforeEach
    void setUp() {
        alien = new Alien(10, 15);
    }

    @Test
    void testConstructor() {
        assertNotNull(alien);
        assertEquals(10, alien.calculateTotalAttack());
        assertEquals(15, alien.calculateTotalDefense());
        assertEquals("Alien", alien.getName());
    }

    @Test
    void testGetLegCount() {
        assertEquals(0, alien.getLegCount());
    }

    @Test
    void testGetHeadCount() {
        assertEquals(3, alien.getHeadCount());
    }

    @Test
    void testGetArmCount() {
        assertEquals(8, alien.getArmCount());
    }
}
