import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HeadGearTest {

    private HeadGear headGear;

    @BeforeEach
    void setUp() {
        headGear = new HeadGear("TestHelmet", "Magic", 5, 10);
    }

    @Test
    void testConstructor() {
        assertEquals("TestHelmet", headGear.getName());
        assertEquals("Magic", headGear.getPrefix());
        assertEquals(10, headGear.getDefenseStrength());
        assertEquals(5, headGear.getAttackStrength());
    }

    @Test
    void testGetBodyPartToEquip() {
        assertEquals(EquippableBodyPart.HEAD, headGear.getBodyPartToEquip());
    }

    @Test
    void testEquip() {
        // If there's additional functionality in the `equip` method, test that here
    }

    @Test
    void testUnequip() {
        // If there's additional functionality in the `unequip` method, test that here
    }
}
