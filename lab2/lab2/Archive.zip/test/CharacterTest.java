import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ConcreteCharacter extends Character {
    public ConcreteCharacter(int baseAttack, int baseDefense) {
        super(baseAttack, baseDefense, "TestCharacter");
    }

    public int getLegCount() { return 2; }
    public int getHeadCount() { return 1; }
    public int getArmCount() { return 2; }
}

public class CharacterTest {

    private ConcreteCharacter character;

    @BeforeEach
   public  void setUp() {
        character = new ConcreteCharacter(10, 20);
    }

    @Test
    public void testConstructor() {
        assertEquals(10, character.calculateTotalAttack());
        assertEquals(20, character.calculateTotalDefense());
        assertEquals("TestCharacter", character.getName());
    }

    @Test
    public void testCalculateTotalAttack() {
        Item item = new Footwear("Item1", "Prefix1", 5, 0); // Example item
        character.pickUpItem(item);
        assertEquals(15, character.calculateTotalAttack());
    }

    @Test
    public void testCalculateTotalDefense() {
        Item item = new Footwear("Item2", "Prefix2", 0, 5); // Example item
        character.pickUpItem(item);
        assertEquals(25, character.calculateTotalDefense());
    }

    @Test
    public void testCanEquipMoreItems() {
        assertTrue(character.canEquipMoreItems());
        // You can also test with a filled inventory here
    }

    @Test
    public   void testCanEquipMoreItemsForBodyPart() {
        assertTrue(character.canEquipMoreItems(EquippableBodyPart.LEGS));
        // You can also test with a filled inventory here
    }

    @Test
    public  void testGetBodyPartCount() {
        assertEquals(2, character.getBodyPartCount(EquippableBodyPart.LEGS));
        assertEquals(1, character.getBodyPartCount(EquippableBodyPart.HEAD));
        assertEquals(2, character.getBodyPartCount(EquippableBodyPart.ARMS));
    }
}
