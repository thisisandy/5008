import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ItemTest {

    @Test
    void testItemProperties() {
        String name = "Sword";
        String prefix = "Sharp";
        int attackStrength = 15;
        int defenseStrength = 5;

        Item item = new Item(name, prefix, attackStrength,defenseStrength);

        assertEquals(name, item.getName());
        assertEquals(prefix, item.getPrefix());
        assertEquals(attackStrength, item.getAttackStrength());
        assertEquals(defenseStrength, item.getDefenseStrength());
    }

    @Test
    void testItemCombination() {
        Item item1 = new Item("Sword", "Sharp", 5, 15);
        Item item2 = new Item("Shield", "Sturdy", 10, 5);

        Item combinedItem = item1.combine(item2);

        assertEquals("Sword", combinedItem.getName());
        assertEquals("SharpSturdy", combinedItem.getPrefix());
        assertEquals(15, combinedItem.getAttackStrength());
        assertEquals(20, combinedItem.getDefenseStrength());
    }
}
