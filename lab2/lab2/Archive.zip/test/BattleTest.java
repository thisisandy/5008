import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BattleTest {

    private Battle battle;

    @BeforeEach
    void setUp() {
        battle = new Battle();
    }

    @AfterEach
    void tearDown() {
        battle = null;
    }

    @Test
    void generateRandomItems() {
        int count = 20;
        Item[] items = battle.generateRandomItems(count);
        assertEquals(count, items.length);
        for (Item item : items) {
            assertTrue(item instanceof Footwear || item instanceof HeadGear || item instanceof HandGear);
        }
    }

    @Test
    void generateRandomCharacter() {
        Character character = battle.generateRandomCharacter();
        assertTrue(character instanceof Human || character instanceof Alien);
    }

}
