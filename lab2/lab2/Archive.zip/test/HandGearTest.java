import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HandGearTest {

    private HandGear handGear;

    @BeforeEach
    void setUp() {
        handGear = new HandGear("TestGloves", "Magic", 5, 10);
    }

    @Test
    void testConstructor() {
        assertEquals("TestGloves", handGear.getName());
        assertEquals("Magic", handGear.getPrefix());
        assertEquals(10, handGear.getDefenseStrength());
        assertEquals(5, handGear.getAttackStrength());
    }

    @Test
    void testGetBodyPartToEquip() {
        assertEquals(EquippableBodyPart.ARMS, handGear.getBodyPartToEquip());
    }

    @Test
    void testEquip() {
        // If there's additional functionality in the `equip` method, test that here
    }

    @Test
    void testUnequip() {
        // If there's additional functionality in the `unequip` method, test that here
    }
}
