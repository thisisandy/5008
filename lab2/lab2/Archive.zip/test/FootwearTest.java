import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FootwearTest {

    private Footwear footwear;

    @BeforeEach
    void setUp() {
        footwear = new Footwear("TestBoots", "Magic", 5, 10);
    }

    @Test
    void testConstructor() {
        assertEquals("TestBoots", footwear.getName());
        assertEquals("Magic", footwear.getPrefix());
        assertEquals(10, footwear.getDefenseStrength());
        assertEquals(5, footwear.getAttackStrength());
    }

    @Test
    void testGetBodyPartToEquip() {
        assertEquals(EquippableBodyPart.LEGS, footwear.getBodyPartToEquip());
    }

    @Test
    void testEquip() {
        // If there's additional functionality in the `equip` method, test that here
    }

    @Test
    void testUnequip() {
        // If there's additional functionality in the `unequip` method, test that here
    }
}
