import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {

    private Inventory inventory;
    private Character character;

    @BeforeEach
    void setUp() {
        character = new Human(10, 5);
        inventory = new Inventory(character);
    }

    @Test
    void testInitializeSlots() {
        Map<EquippableBodyPart, Slot> slots = inventory.getSlots();
        assertEquals(character.getBodyPartCount(EquippableBodyPart.HEAD), slots.get(EquippableBodyPart.HEAD).getCapacity());
        assertEquals(character.getBodyPartCount(EquippableBodyPart.ARMS), slots.get(EquippableBodyPart.ARMS).getCapacity());
        assertEquals(character.getBodyPartCount(EquippableBodyPart.LEGS), slots.get(EquippableBodyPart.LEGS).getCapacity());
    }

    @Test
    void testAddAndRemoveItem() {
        Item item = new Footwear("Boots", "Strong", 3, 2);
        assertFalse(inventory.isFull());
        inventory.addItem(item);
        assertEquals(item, inventory.getSlots().get(EquippableBodyPart.LEGS).getItems()[0]);

        inventory.removeItem(item);
        assertNull(inventory.getSlots().get(EquippableBodyPart.LEGS).getItems()[0]);
    }

    @Test
    void testEquipAndUnequipItem() {
        Item item = new HandGear("Gloves", "Mighty", 2, 4);
        assertFalse(inventory.isFull());
        inventory.equipItem(item);
        assertEquals(item, inventory.getSlots().get(EquippableBodyPart.ARMS).getItems()[0]);

        inventory.unequipItem(item);
        assertNull(inventory.getSlots().get(EquippableBodyPart.ARMS).getItems()[0]);
    }
}
