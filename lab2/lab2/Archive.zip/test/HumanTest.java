import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HumanTest {

    private Human human;

    @BeforeEach
    void setUp() {
        human = new Human(10, 5);
    }

    @Test
    void testConstructor() {
        assertEquals(10, human.calculateTotalAttack());
        assertEquals(5, human.calculateTotalDefense());
        assertEquals("Human", human.getName());
    }

    @Test
    void testGetLegCount() {
        assertEquals(2, human.getLegCount());
    }

    @Test
    void testGetHeadCount() {
        assertEquals(1, human.getHeadCount());
    }

    @Test
    void testGetArmCount() {
        assertEquals(2, human.getArmCount());
    }
}
